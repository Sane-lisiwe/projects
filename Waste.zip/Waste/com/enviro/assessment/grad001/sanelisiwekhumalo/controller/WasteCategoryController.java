package com.enviro.assessment.grad001.sanelisiwekhumalo.controller;

import com.enviro.assessment.grad001.sanelisiwekhumalo.model.WasteCategory;
import com.enviro.assessment.grad001.sanelisiwekhumalo.service.WasteCategoryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * REST Controller for managing waste categories.
 * Provides endpoints for CRUD operations on waste categories.
 */
@RestController
@RequestMapping("/api/waste-categories")
@Validated
public class WasteCategoryController {

    private final WasteCategoryService wasteCategoryService;

    @Autowired
    public WasteCategoryController(WasteCategoryService wasteCategoryService) {
        this.wasteCategoryService = wasteCategoryService;
    }

    /**
     * Creates a new waste category
     
     * return The created waste category with HTTP 201 status
     */
    @PostMapping
    public ResponseEntity<WasteCategory> createWasteCategory(@Validated @RequestBody WasteCategory wasteCategory) {
        return new ResponseEntity<>(wasteCategoryService.createWasteCategory(wasteCategory), HttpStatus.CREATED);
    }

    /**
     * Retrieves all waste categories
     * return List of all waste categories
     */
    @GetMapping
    public List<WasteCategory> getAllWasteCategories() {
        return wasteCategoryService.getAllWasteCategories();
    }

    /**
     * Retrieves a specific waste category by ID
     * @param id The ID of the waste category to retrieve
     * return The waste category if found, or 404 if not found
     */
    @GetMapping("/{id}")
    public ResponseEntity<WasteCategory> getWasteCategoryById(@PathVariable Long id) {
        return wasteCategoryService.getWasteCategoryById(id)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Updates an existing waste category
     * @param id The ID of the waste category to update
     * @param wasteCategory The updated waste category data
     * return The updated waste category if found, or 404 if not found
     */
    @PutMapping("/{id}")
    public ResponseEntity<WasteCategory> updateWasteCategory(
            @PathVariable Long id,
            @Validated @RequestBody WasteCategory wasteCategory) {
        return wasteCategoryService.updateWasteCategory(id, wasteCategory)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    /**
     * Deletes a waste category
     * @param id The ID of the waste category to delete
     * return 204 if deleted, 404 if not found
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWasteCategory(@PathVariable Long id) {
        if (wasteCategoryService.deleteWasteCategory(id)) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.notFound().build();
    }
} 