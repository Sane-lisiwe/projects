package com.enviro.assessment.grad001.sanelisiwekhumalo.service;

import com.enviro.assessment.grad001.sanelisiwekhumalo.model.WasteCategory;
import com.enviro.assessment.grad001.sanelisiwekhumalo.repository.WasteCategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Service class for managing waste categories.
 * Implements business logic for CRUD operations on waste categories.
 */
@Service
public class WasteCategoryService {

    private final WasteCategoryRepository repository;

    @Autowired
    public WasteCategoryService(WasteCategoryRepository repository) {
        this.repository = repository;
    }

    /**
     * Creates a new waste category
     * @param wasteCategory The waste category to create
     * return The created waste category
     */
    public WasteCategory createWasteCategory(WasteCategory wasteCategory) {
        return repository.save(wasteCategory);
    }

    /**
     * Retrieves all waste categories
     * return List of all waste categories
     */
    public List<WasteCategory> getAllWasteCategories() {
        return repository.findAll();
    }

    /**
     * Retrieves a specific waste category by ID
     * @param id The ID of the waste category to retrieve
     *return Optional containing the waste category if found
     */
    public Optional<WasteCategory> getWasteCategoryById(Long id) {
        return repository.findById(id);
    }

    /**
     * Updates an existing waste category
     * @param id The ID of the waste category to update
     * @param wasteCategory The updated waste category data
     * return Optional containing the updated waste category if found
     */
    public Optional<WasteCategory> updateWasteCategory(Long id, WasteCategory wasteCategory) {
        if (!repository.existsById(id)) {
            return Optional.empty();
        }
        wasteCategory.setId(id);
        return Optional.of(repository.save(wasteCategory));
    }

    /**
     * Deletes a waste category
     * @param id The ID of the waste category to delete
     * return true if deleted, false if not found
     */
    public boolean deleteWasteCategory(Long id) {
        if (!repository.existsById(id)) {
            return false;
        }
        repository.deleteById(id);
        return true;
    }
} 