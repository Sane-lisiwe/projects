package com.enviro.assessment.grad001.sanelisiwekhumalo.model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;
import lombok.Data;

/**
 * Entity class representing a waste category.
 * Contains information about different types of waste,
 * including disposal guidelines and recycling tips.
 */
@Entity
@Data
public class WasteCategory {
    /**
     * Unique identifier for the waste category
     */
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /**
     * Name of the waste category
     * Cannot be blank and must not exceed 100 characters
     */
    @NotBlank(message = "Category name cannot be blank")
    @Size(max = 100, message = "Category name cannot exceed 100 characters")
    private String name;

    /**
     * Guidelines for proper disposal of this waste category
     */
    @NotBlank(message = "Disposal guideline cannot be blank")
    @Column(length = 1000)
    private String disposalGuideline;

    /**
     * Tips for recycling this type of waste
     */
    @NotBlank(message = "Recycling tip cannot be blank")
    @Column(length = 1000)
    private String recyclingTip;
} 