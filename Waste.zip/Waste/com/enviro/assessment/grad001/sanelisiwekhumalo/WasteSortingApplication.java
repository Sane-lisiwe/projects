package com.enviro.assessment.grad001.sanelisiwekhumalo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Spring Boot Application class for the Waste Sorting Application.
 * This application provides REST APIs for managing waste categories,
 * disposal guidelines, and recycling tips.
 */
@SpringBootApplication
public class WasteSortingApplication {
    public static void main(String[] args) {
        SpringApplication.run(WasteSortingApplication.class, args);
    }
} 