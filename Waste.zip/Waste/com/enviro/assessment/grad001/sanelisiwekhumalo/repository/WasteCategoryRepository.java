package com.enviro.assessment.grad001.sanelisiwekhumalo.repository;

import com.enviro.assessment.grad001.sanelisiwekhumalo.model.WasteCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Repository interface for WasteCategory entity.
 * Provides CRUD operations for WasteCategory entities using Spring Data JPA.
 */
@Repository
public interface WasteCategoryRepository extends JpaRepository<WasteCategory, Long> {} 